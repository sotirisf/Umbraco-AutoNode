﻿using System.Linq;
using Umbraco.Core;
using Umbraco.Core.Events;
using Umbraco.Core.Models;
using Umbraco.Core.Services;
using Umbraco.Web;
using Umbraco.Web.Routing;

namespace DotSee
{
    public class AutoNodeEvents : ApplicationEventHandler
    {

        protected override void ApplicationStarted(UmbracoApplicationBase umbracoApplication, ApplicationContext applicationContext)
        {
            base.ApplicationStarted(umbracoApplication, applicationContext);

            AutoNode au = AutoNode.Instance;

            //Register your own rules here! Below is an example that creates a document of doctype "Dummy" when a document of doctype "TextPage"
            //is published. Nodes will be sorted so that this new one gets to be first (not last, which is the default) and it will be created regardless of 
            //whether there are any other subnodes. (Of course, if it already exists, it won't be created a second time).
            //au.RegisterRule(new AutoNodeRule(
            //    createdDocTypealias: "TextPage",
            //    docTypeAliasToCreate: "Dummy",
            //    nodeName: "Dummy Auto Inserted Node",
            //    bringNodeFirst: true,
            //    onlyCreateIfNoChildren: false));

            ContentService.Saved += ContentServiceSaved;

        }

        private void ContentServiceSaved(IContentService sender, SaveEventArgs<IContent> args)
        {

            foreach (IContent node in args.SavedEntities)
            {
                AutoNode.Instance.Run(node);
            }
        }


    }


}